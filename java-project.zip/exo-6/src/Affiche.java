package sn.ugb.sat.info.licence3.exercice1;

public class Affiche {
    public static void afficheCar(int n, char ch){
        for(int i=1; i<=n; i++)
            System.out.print(ch);
    }
}